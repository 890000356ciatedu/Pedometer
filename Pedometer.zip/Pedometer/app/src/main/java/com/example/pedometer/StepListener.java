package com.example.pedometer;

public interface StepListener {
    public void step(long timeNs);
}
